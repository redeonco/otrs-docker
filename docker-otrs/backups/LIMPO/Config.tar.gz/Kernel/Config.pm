# --
# Kernel/Config.pm - Config file for OTRS kernel
# Copyright (C) 2001-2013 OTRS AG, http://otrs.org/
# --
# This software comes with ABSOLUTELY NO WARRANTY. For details, see
# the enclosed file COPYING for license information (AGPL). If you
# did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
# --
#  Note:
#
#  -->> Most OTRS configuration should be done via the OTRS web interface
#       and the SysConfig. Only for some configuration, such as database
#       credentials and customer data source changes, you should edit this
#       file. For changes do customer data sources you can copy the definitions
#       from Kernel/Config/Defaults.pm and paste them in this file.
#       Config.pm will not be overwritten when updating OTRS.
# --

package Kernel::Config;

use strict;
use warnings;
use utf8;

sub Load {
    my $Self = shift;
    
	
    ##########################################################################
    # Autentica��o de Atendentes 					     #
    #- Aqui definimos a integra��o que permite ao OTRS autenticar usu�rios   #
    # a partir do Active Directory de sua organiza��o. 			     #
    #- Importante: os usu�rio devem possuir o campo �email� preenchido 	     #
    # no AD para poderem se autenticar 					     #
    ########################################################################## 

    # Este � um exemplo de configura��o para autentica��o LDAP. Processo interno.
    # (certifique-se de que Net :: LDAP est� instalado!)
	
    $Self->{AuthModule1} = 'Kernel::System::Auth::LDAP';
	
    # Abaixo, colocamos o IP ou hostname do servidor
    $Self->{'AuthModule::LDAP::Host1'} = 'SRVIMPDC01';
    
    # A seguir, o DistinguishedName (DN) onde buscaremos os usu�rios
    $Self->{'AuthModule::LDAP::BaseDN1'} = 'dc=oncoradium,dc=corp';

    # A seguir, a propriedade do AD onde encontraremos o nome de usu�rio
    $Self->{'AuthModule::LDAP::UID1'} = 'sAMAccountName';

    
    # Aqui definimos em qual grupo o usu�rio deve estar para poder se logar no OTRS
    # Este parametro � opcional e pode ser comentado com #
    $Self->{'AuthModule::LDAP::GroupDN1'} = 'CN=otrs_agentes,OU=OTRS,OU=Grupos,DC=oncoradium,DC=corp';
    $Self->{'AuthModule::LDAP::AccessAttr1'} = 'member';
    $Self->{'AuthModule::LDAP::UserAttr1'} = 'DN';

    # Aqui definimos o usu�rio e senha de uma conta que tenha permiss�o de buscar informa��es na �rvore de nosso AD.
    # � aconselhavel criar um usu�rio exclusivo para o OTRS
    $Self->{'AuthModule::LDAP::SearchUserDN1'} = 'CN=OTRS ADM,OU=Administracao,DC=oncoradium,DC=corp';
    $Self->{'AuthModule::LDAP::SearchUserPw1'} = '@Onc0r4d1um@';

    # Note que h� o n�mero �1� no fim das defini��es realizadas entre �{ }�
    # O OTRS permite que voc� se conecte com at� 9 m�dulos diferentes de autentica��o, ou 9 Ads diferentes por exemplo.

    # Caso voc� queira adicionar sempre um filtro para cada consulta ldap, use
    # Essa op��o por exemplo AlwaysFilter => '(mail=*)' or AlwaysFilter => '(objectclass=user)'
    $Self->{'AuthModule::LDAP::AlwaysFilter1'} = '';

    # Net::LDAP new params (if needed - for more info see perldoc Net::LDAP)
    $Self->{'AuthModule::LDAP::Params'} = {
        port    => 389,
        timeout => 120,
        async   => 0,
        version => 3,
    };
	
    # Usu�rios do AD como Clientes do OTRS

	###################################################################
	# Exibe os colaboradores do AD como clientes internos 		  #
	# Lembre-se que os usu�rios no AD devem ter o campo mail	  #
	# preenchido corretamente 					  #
	###################################################################
	
    # Este � um exemplo de configura��o para autentica��o LDAP. Processo interno.
    # (certifique-se de que Net :: LDAP est� instalado!)

    $Self->{AuthSyncModule1} = 'Kernel::System::Auth::Sync::LDAP';
    $Self->{'AuthSyncModule::LDAP::Host1'} = 'SRVIMPDC01';
    $Self->{'AuthSyncModule::LDAP::BaseDN1'} = 'dc=oncoradium,dc=corp';
    $Self->{'AuthSyncModule::LDAP::UID1'} = 'sAMAccountName';

    # The following is valid but would only be necessary if the
    # anonymous user do NOT have permission to read from the LDAP tree
    $Self->{'AuthSyncModule::LDAP::SearchUserDN1'} = 'CN=OTRS ADM,OU=Administracao,DC=oncoradium,DC=corp';
    $Self->{'AuthSyncModule::LDAP::SearchUserPw1'} = '@Onc0r4d1um@';
  
 
    # AuthSyncModule::LDAP::UserSyncMap
    # (mapear se o agente deve criar / sincronizar do LDAP para o banco de dados ap�s o login bem-sucedido)
    # voc� pode especificar campos-LDAP como
    # * lista, que verificar� cada campo. o primeiro existente ser� escolhido (["givenName", "cn", "_ empty"])
    # * nome de um campo LDAP (pode retornar strings vazias) ("givenName")
    # * strings fixas, prefixadas com um sublinhado: "_test", que sempre retornar� esta string fixa
    $Self->{'AuthSyncModule::LDAP::UserSyncMap1'} = {
    # # DB -> LDAP
        UserFirstname => 'givenName',
        UserLastname  => 'sn',
        UserEmail     => 'mail',
    };

        ###################################################################
	# 								  #
	#       Autentica��o de Cliente no Active Directory	 	  #
        #								  #
	###################################################################
	
    # Este � o m�dulo de autentica��o para o otrs db
    # Voc� tamb�m pode configur�-lo usando um banco de dados remoto	

	
	$Self->{'Customer::AuthModule2'} = 'Kernel::System::CustomerAuth::LDAP';
	$Self->{'Customer::AuthModule::LDAP::Host2'} = 'SRVIMPDC01.oncoradium.corp';
	$Self->{'Customer::AuthModule::LDAP::BaseDN2'} = 'dc=oncoradium,dc=corp';
	$Self->{'Customer::AuthModule::LDAP::UID2'} = 'sAMAccountName';
        
        # A linha abaixo serve para permitir que apenas usu�rios de um determinado grupo acessem o sistema como clientes
	$Self->{'Customer::AuthModule::LDAP::GroupDN2'} = 'CN=otrs_usuarios,OU=OTRS,OU=Grupos,DC=oncoradium,DC=corp';
        $Self->{'Customer::AuthModule::LDAP::AccessAttr2'} = 'member';
    
	# Para LDAP posixGroups objectclass (apenas UID)
    #   $Self->{'Customer::AuthModule::LDAP::UserAttr'} = 'UID';
    
	# for non ldap posixGroups objectclass (full user dn)
        $Self->{'Customer::AuthModule::LDAP::UserAttr2'} = 'DN';

        $Self->{'Customer::AuthModule::LDAP::SearchUserDN2'} = 'CN=OTRS ADM,OU=Administracao,DC=oncoradium,DC=corp';
        $Self->{'Customer::AuthModule::LDAP::SearchUserPw2'} = '@Onc0r4d1um@';

    # Caso voc� queira adicionar sempre um filtro para cada consulta ldap, use
    # Esta op��o - AlwaysFilter => '(mail = *)' ou AlwaysFilter => '(objectclass = user)'
    $Self->{'Customer::AuthModule::LDAP::AlwaysFilter2'} = '';

    # in your ldap directory exists user@domain.
#   $Self->{'Customer::AuthModule::LDAP::UserSuffix'} = '@oncoradium.corp.com';

    # Net::LDAP new params (if needed - for more info see perldoc Net::LDAP)
#   $Self->{'Customer::AuthModule::LDAP::Params2'} = {
#        port    => 389,
#        timeout => 120,
#        async   => 0,
#        version => 3,
#    };

    # Atributos necess�rios para sincroniza��es de grupo
    # (nome do atributo para chave de valor de grupo)
    $Self->{'AuthSyncModule::LDAP::AccessAttr1'} = 'member';

    # (atributo para o tipo de conte�do do grupo UID / DN para o nome completo do LDAP)
#   $Self->{'AuthSyncModule::LDAP::UserAttr1'} = 'sAMAccountName';
#   $Self->{'AuthSyncModule::LDAP::UserAttr'} = 'DN';

    # AuthSyncModule::LDAP::UserSyncInitialGroups
    # (sincronizar o seguinte grupo com permiss�o rw ap�s a cria��o inicial do login do primeiro agente)
    $Self->{'AuthSyncModule::LDAP::UserSyncInitialGroups1'} = [
        'users',
    ];

    # AuthSyncModule::LDAP::UserSyncGroupsDefinition
    # (Se "LDAP" foi selecionado para AuthModule e voc� deseja sincronizar o LDAP
    # grupos para outros grupos, defina o seguinte.)
    $Self->{'AuthSyncModule::LDAP::UserSyncGroupsDefinition1'} = {
#        # Grupo LDAP
        'CN=otrs_admin,OU=OTRS,OU=Grupos,DC=oncoradium,DC=corp' => {
            # Grupo OTRS
            'admin' => {
                # Permiss�o
                rw => 1,
                ro => 1,
            },
			'Hardware Group Users' => {
                # Permiss�o
                rw => 1,
                ro => 1,
            },
#            'faq' => {
#                rw => 0,
#                ro => 1,
#            },
        },
        'CN=otrs_agentes,OU=OTRS,OU=Grupos,DC=oncoradium,DC=corp' => {
            'users' => {
                rw => 0,
                ro => 0,
            },
			'Hardware Group Users' => {
                # Permiss�o
                rw => 0,
                ro => 0,
				}
        }
    };
	
    # --------------------------------------------------- #
    # configura��es de autentica��o do cliente            #
    # --------------------------------------------------- #

	$Self->{'Customer::AuthModule2'} = 'Kernel::System::CustomerAuth::LDAP';
	$Self->{'Customer::AuthModule::LDAP::Host2'} = 'SRVIMPDC01.oncoradium.corp';
	$Self->{'Customer::AuthModule::LDAP::BaseDN2'} = 'dc=oncoradium,dc=corp';
	$Self->{'Customer::AuthModule::LDAP::UID2'} = 'sAMAccountName';
	$Self->{'Customer::AuthModule::LDAP::GroupDN2'} = 'CN=otrs_usuarios,OU=OTRS,OU=Grupos,DC=oncoradium,DC=corp';
    	$Self->{'Customer::AuthModule::LDAP::AccessAttr2'} = 'member';

#   $Self->{'Customer::AuthModule::LDAP::UserAttr'} = 'UID';
    $Self->{'Customer::AuthModule::LDAP::UserAttr2'} = 'DN';
    $Self->{'Customer::AuthModule::LDAP::SearchUserDN2'} = 'CN=OTRS ADM,OU=Administracao,DC=oncoradium,DC=corp';
    $Self->{'Customer::AuthModule::LDAP::SearchUserPw2'} = '@Onc0r4d1um@';
    $Self->{'Customer::AuthModule::LDAP::AlwaysFilter2'} = '';
	$Self->{'CustomerUser2'} = {
    Module => 'Kernel::System::CustomerUser::LDAP',
    Params => {
        Host => 'SRVIMPDC01.oncoradium.corp',
        BaseDN => 'DC=oncoradium,DC=corp',
        SSCOPE => 'sub',
        UserDN =>'CN=OTRS ADM,OU=Administracao,DC=oncoradium,DC=corp',
        UserPw => '@Onc0r4d1um@',
        AlwaysFilter => '(&(samAccountType=805306368)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))',
        SourceCharset => 'utf-8',
        DestCharset => 'utf-8',
    },
    CustomerKey => 'sAMAccountName',
    CustomerID => 'department',
    CustomerUserListFields => ['sAMAccountName', 'cn', 'mail'],
    CustomerUserSearchFields => ['sAMAccountName', 'cn', 'mail'],
    CustomerUserSearchPrefix => '',
    CustomerUserSearchSuffix => '*',
    CustomerUserSearchListLimit => 10000,
    CustomerUserPostMasterSearchFields => ['mail'],
    CustomerUserNameFields => ['givenname', 'sn'],
    Map => [
#        # note: Login, Email and CustomerID needed!
        [ 'UserFirstname', 'Firstname', 'givenname', 1, 1, 'var' ],
        [ 'UserLastname', 'Lastname', 'sn', 1, 1, 'var' ],
        [ 'UserLogin', 'Login', 'sAMAccountName', 1, 1, 'var' ],
        [ 'UserEmail', 'Email', 'mail', 1, 1, 'var' ],
        [ 'UserCustomerID', 'CustomerID', 'department', 1, 1, 'var' ],
        [ 'UserPhone', 'Phone', 'telephoneNumber', 1, 0, 'var' ],
    ],
};	

  # ---------------------------------------------------- #
    # database settings                                    #
    # ---------------------------------------------------- #

    # The database host
    $Self->{'DatabaseHost'} = 'mariadb';

    # The database name
    $Self->{'Database'} = "otrs";

    # The database user
    $Self->{'DatabaseUser'} = "otrs";

    # The password of database user. You also can use bin/otrs.CryptPassword.pl
    # for crypted passwords
    $Self->{'DatabasePw'} = 'changeme';

    # The database DSN for MySQL ==> more: "perldoc DBD::mysql"
    $Self->{'DatabaseDSN'} = "DBI:mysql:database=$Self->{Database};host=$Self->{DatabaseHost}";

    # The database DSN for PostgreSQL ==> more: "perldoc DBD::Pg"
    # if you want to use a local socket connection
#    $Self->{DatabaseDSN} = "DBI:Pg:dbname=$Self->{Database};";
    # if you want to use a TCP/IP connection
#    $Self->{DatabaseDSN} = "DBI:Pg:dbname=$Self->{Database};host=$Self->{DatabaseHost};";
    # if you have PostgresSQL 8.1 or earlier, activate the legacy driver with this line:
#    $Self->{DatabasePostgresqlBefore82} = 1;

    # The database DSN for Microsoft SQL Server - only supported if OTRS is
    # installed on Windows as well
#    $Self->{DatabaseDSN} = "DBI:ODBC:driver={SQL Server};Database=$Self->{Database};Server=$Self->{DatabaseHost},1433";

    # The database DSN for Oracle ==> more: "perldoc DBD::oracle"
#    $ENV{ORACLE_HOME} = '/u01/app/oracle/product/10.2.0/client_1';
#    $ENV{NLS_DATE_FORMAT} = 'YYYY-MM-DD HH24:MI:SS';
#    $ENV{NLS_LANG} = "american_america.utf8";

#    $Self->{DatabaseDSN} = "DBI:Oracle:sid=OTRS;host=$Self->{DatabaseHost};port=1522;";

    # ---------------------------------------------------- #
    # fs root directory
    # ---------------------------------------------------- #
    $Self->{Home} = '/opt/otrs';
$Self->{'SecureMode'} = '1';
#$Self->{'FQDN'} = 'otrs-FF0blNXZ';
$Self->{'DatabasePort'} = '3306';

    # ---------------------------------------------------- #
    # insert your own config settings "here"               #
    # config settings taken from Kernel/Config/Defaults.pm #
    # ---------------------------------------------------- #
    # $Self->{SessionUseCookie} = 0;
    # $Self->{CheckMXRecord} = 0;

    # ---------------------------------------------------- #

    # ---------------------------------------------------- #
    # data inserted by installer                           #
    # ---------------------------------------------------- #
    # $DIBI$

    # ---------------------------------------------------- #
    # ---------------------------------------------------- #
    #                                                      #
    # end of your own config options!!!                    #
    #                                                      #
    # ---------------------------------------------------- #
    # ---------------------------------------------------- #
}

# ---------------------------------------------------- #
# needed system stuff (don't edit this)                #
# ---------------------------------------------------- #

use base qw(Kernel::Config::Defaults);

# -----------------------------------------------------#

1;
